var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
export function initItemSheetDropHandler() {
    var _a;
    // @ts-ignore
    const originalDropHandler = ItemSheet.prototype._onDrop;
    // @ts-ignore
    ItemSheet.prototype._onDrop = function (event) {
        return __awaiter(this, void 0, void 0, function* () {
            if ((event === null || event === void 0 ? void 0 : event.dataTransfer) != null) {
                try {
                    const data = JSON.parse(event.dataTransfer.getData('text/plain'));
                    yield dropData(data, this);
                }
                catch (err) {
                    console.error(err);
                }
            }
            if (originalDropHandler != null) {
                originalDropHandler.call(this, event);
            }
        });
    };
    const defaultOption = ItemSheet.defaultOptions;
    (_a = defaultOption.dragDrop) === null || _a === void 0 ? void 0 : _a.push({ dragSelector: '.item-list .item', dropSelector: null });
    Object.defineProperty(ItemSheet, 'defaultOptions', {
        get: () => {
            return defaultOption;
        }
    });
}
function dropData(data, sheet) {
    return __awaiter(this, void 0, void 0, function* () {
        if (data == null) {
            return;
        }
        switch (data.type) {
            case 'Item':
                const item = yield Item.fromDropData(data);
                yield dropItem(item, sheet);
                break;
        }
    });
}
function dropItem(item, sheet) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w;
    return __awaiter(this, void 0, void 0, function* () {
        if (item == null || sheet == null) {
            return;
        }
        switch (`${(_b = (_a = sheet.item) === null || _a === void 0 ? void 0 : _a.type) === null || _b === void 0 ? void 0 : _b.toLowerCase()}-${(_c = item.type) === null || _c === void 0 ? void 0 : _c.toLowerCase()}`) {
            case 'career-skill':
                const currentSkills = filterEmpty((_f = (_e = (_d = sheet.item) === null || _d === void 0 ? void 0 : _d.data) === null || _e === void 0 ? void 0 : _e.data) === null || _f === void 0 ? void 0 : _f.skills);
                currentSkills.push(item.name);
                (_g = sheet.item) === null || _g === void 0 ? void 0 : _g.update({ 'data.skills': currentSkills });
                break;
            case 'career-talent':
            case 'career-trait':
                const currentTalents = filterEmpty((_k = (_j = (_h = sheet.item) === null || _h === void 0 ? void 0 : _h.data) === null || _j === void 0 ? void 0 : _j.data) === null || _k === void 0 ? void 0 : _k.talents);
                currentTalents.push(item.name);
                (_l = sheet.item) === null || _l === void 0 ? void 0 : _l.update({ 'data.talents': currentTalents });
                break;
            case 'career-trapping':
            case 'career-ammunition':
            case 'career-armour':
            case 'career-container':
            case 'career-money':
            case 'career-weapon':
                const currentTrappings = filterEmpty((_p = (_o = (_m = sheet.item) === null || _m === void 0 ? void 0 : _m.data) === null || _o === void 0 ? void 0 : _o.data) === null || _p === void 0 ? void 0 : _p.trappings);
                currentTrappings.push(item.name);
                (_q = sheet.item) === null || _q === void 0 ? void 0 : _q.update({ 'data.trappings': currentTrappings });
                break;
            case 'talent-skill':
                const currentTests = trimedFilterEmpty((_v = (_u = (_t = (_s = (_r = sheet.item) === null || _r === void 0 ? void 0 : _r.data) === null || _s === void 0 ? void 0 : _s.data) === null || _t === void 0 ? void 0 : _t.tests) === null || _u === void 0 ? void 0 : _u.value) === null || _v === void 0 ? void 0 : _v.split(','));
                currentTests.push(item.name);
                (_w = sheet.item) === null || _w === void 0 ? void 0 : _w.update({ 'data.tests.value': currentTests.join(', ') });
                break;
        }
    });
}
function filterEmpty(list) {
    return list != null ? list.filter((element) => element != null && element.trim() !== '') : [];
}
function trimedFilterEmpty(list) {
    return filterEmpty(list).map((element) => element.trim());
}
//# sourceMappingURL=item-sheet.js.map