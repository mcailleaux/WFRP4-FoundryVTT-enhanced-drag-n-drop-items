import { initItemSheetDropHandler } from './item-sheet.js';
Hooks.once('init', () => {
    initItemSheetDropHandler();
});
//# sourceMappingURL=main.js.map