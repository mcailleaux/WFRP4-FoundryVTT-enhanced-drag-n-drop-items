export declare function initItemSheetDropHandler(): void;
